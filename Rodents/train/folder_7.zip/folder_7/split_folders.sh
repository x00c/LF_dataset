#!/bin/bash

# Set the maximum size per folder (in bytes, 23 MB = 23 * 1024 * 1024)
MAX_SIZE=$((19 * 1024 * 1024))
folder_index=1
current_size=0

# Create the first folder
mkdir "folder_$folder_index"

for file in *; do
    # Check if it's a file (not a directory)
    if [ -f "$file" ]; then
        file_size=$(stat -f%z "$file")
        
        # If adding this file exceeds the max size, create a new folder
        if (( current_size + file_size > MAX_SIZE )); then
            folder_index=$((folder_index + 1))
            mkdir "folder_$folder_index"
            current_size=0
        fi

        # Move the file into the current folder and update the current size
        mv "$file" "folder_$folder_index"
        current_size=$((current_size + file_size))
    fi
done
