# Airport > 2024-06-13 9:36am
https://universe.roboflow.com/ls01/airport-vse5d

Provided by a Roboflow user
License: CC BY 4.0

